﻿using System.Collections;
using Infosys.EAgriculture.DAL;
using Infosys.EAgriculture.DAL.Models;

namespace Infosys.EAgriculture
{
    public class Program
    {
        private static EagriPortalDbContext context;
        private static EAgricultureRepository repository;
        static Program()
        {
            context = new EagriPortalDbContext();
            repository=new EAgricultureRepository(context);
        }
        static void Main(string[] args)
        {
            // Test Function
            //GetAllUsers();

            GetUserDetailsByID("U112");
            //CropAvailabilityDetail cropAvailabilityDetail = new CropAvailabilityDetail();
            //cropAvailabilityDetail.ListingId = "CR136";
            //cropAvailabilityDetail.FarmerId = "U115";
            //cropAvailabilityDetail.CropName = "Rice";
            //cropAvailabilityDetail.Quantity = 1555;
            //cropAvailabilityDetail.Unit = "kg";
            //cropAvailabilityDetail.PricePerUnit = 27;
            //cropAvailabilityDetail.HarvestDate = new DateOnly(25,5,7);
            //cropAvailabilityDetail.Location = "Village Nashik, Maharashtra";
            //cropAvailabilityDetail.Description = "Brown rice";
            //cropAvailabilityDetail.Status = "OutOfStock";
            //cropAvailabilityDetail.CreatedAt = DateTime.Now;
            //AddNewCropAvailabilityDetails(cropAvailabilityDetail);

            //UpdateCropDetails("CR135", "U106", "Barley", 500, "kg", 39, new DateOnly(2025, 5, 7), "Rural Path, Haryana", "Organic barley grains", "OutOfStock");

            //get cropDetails function calling
            //getCropDetails();

            //get transaction history
            //getTransactionHistory(); 
            // GetShipmentTrackingDetailOfTraders();
            //test();
            //UpdateShipmentByTrader();
            // Console.WriteLine("HELLO WORLD");
            //AddTraderPreference();
            //getPreferedcrops();
        }
        public static void GetAllUsers()
        {
            var usersList = repository.GetAllUsers();
            if (usersList != null)
            {
                Console.WriteLine("{0,-10}{1,-20}{2,-10}","UserID","FullName","Role");
                Console.WriteLine(new String('-',40));
                foreach (var user in usersList) {
                    Console.WriteLine("{0,-10}{1,-20}{2,-10}",user.UserId, user.FullName, user.Role);  
                }
            }
            else
            {
                Console.WriteLine("No Users!");
            }
        }

        public static void GetUserDetailsByID(string userId)
        {
            User userDetails = repository.GetUserDetailsByID(userId);
            if (userDetails != null) 
            {
                Console.WriteLine("UserId: {0}",userDetails.FullName);
                Console.WriteLine("EmailID: {0}",userDetails.Email);
            }
            else
            {
                Console.WriteLine("Invalid User!");
            }
        }

        // get crop details by price
        public static void getCropDetails()
        {

            List<CropAvailabilityDetail> productList = new List<CropAvailabilityDetail>();
            try
            {
                productList = repository.getAllCropDetails();
                if (productList == null)
                {
                    Console.WriteLine("Some Error occurred");
                }
                else if (productList.Count == 0)
                {
                    Console.WriteLine("No Crops available");
                }
                else
                {
                    Console.WriteLine("FarmerID, CropName, Quantity, Unit, PricePerUnit, Location, HarvestDate");
                    Console.WriteLine("-------------------------------------------------------------------------");
                    foreach (var item in productList)
                    {
                        Console.WriteLine("{0,-10} {1,-10} {2,-10} {3,-10} {4,-10} {5,-10} {6,-10}",
                            item.FarmerId, item.CropName, item.Quantity, item.Unit, item.PricePerUnit, item.Location, item.HarvestDate);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("error occurred: "+e.Message);
            }
        }

        //Adding crop details
        //public static void AddNewCropAvailabilityDetails(CropAvailabilityDetail cropAvailabilityDetailsList)
        //{
        //    try
        //    {
        //        bool res = repository.AddNewCropAvailabilityDetails(cropAvailabilityDetailsList);
        //        if (res)
        //        {
        //            Console.WriteLine("Crop Details have been Added successfully!");
        //        }
        //        else
        //        {
        //            Console.WriteLine("Some error occured while Adding the details. Try once again! ");
        //        }
        //    }
        //    catch (Exception)
        //    {
        //        Console.WriteLine("Some Exception Occured!!");
        //    }
        //}


        //Updating crop details
        //public static void UpdateCropDetails(string listId, string farmerId, string cropName, int quantity, string unit, int pricePerUnit, DateOnly harvestDate, string location, string description, string status)
        //{
        //    try
        //    {
        //        bool res = repository.UpdateCropDetails(listId, farmerId, cropName, quantity, unit, pricePerUnit, harvestDate, location, description, status);
        //        if (res)
        //        {
        //            Console.WriteLine("Crop Details Updated Successfully!!");
        //        }
        //        else
        //        {
        //            Console.WriteLine("Some error Occurred. Try again!!");
        //        }
        //    }
        //    catch (Exception)
        //    {
        //        Console.WriteLine("Some Exception Occurred!!");
        //    }
        //}

        // get transaction history method
        public static void getTransactionHistory()
        {
            List<Transaction> productList = new List<Transaction>();
            try
            {
                productList = repository.getTransactionDetails();
                if (productList == null)
                {
                    Console.WriteLine("Some Error occurred");
                }
                else if (productList.Count == 0)
                {
                    Console.WriteLine("There are no transactions available");
                }
                else
                {
                    Console.WriteLine("TransactionId, FarmerID, TraderId, QuantityRequested, OfferedPrice, RequestDate, status");
                    Console.WriteLine("-------------------------------------------------------------------------");
                    foreach (var item in productList)
                    {
                        Console.WriteLine("{0,-10} {1,-10} {2,-10} {3,-10} {4,-10} {5,-20} {6,-50}",
                            item.TransactionId, item.FarmerId, item.TraderId, item.QuantityRequested, item.OfferedPrice, item.RequestDate, item.Status);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("error occurred: " + e.Message);
            }
        }
        public static void GetShipmentTrackingDetailOfTraders()
        {
            string traderID = "U117";
            var shipmentList = repository.GetShipmentTrackingDetailOfTraders(traderID);
            if(shipmentList != null)
            {
                Console.WriteLine("ShipmentID TransactionID FarmName Status ExpectedDeliveryDate");
                Console.WriteLine(new String('-', 40));
                foreach (var shipment in shipmentList)
                {

                    Console.WriteLine(shipment.ShipmentId+" "+shipment.TransactionId
                        +" "+shipment.FarmName+" "+shipment.Status+" "+shipment.ExpectedDeliveryDate);
                }
            }
            else
            {
                Console.WriteLine("Empty");
            }
                
        }
        public static void UpdateShipmentByTrader()
        {
            try
            {  string status = "Cancelled";
                string shipmentID = "SH116";
                bool check = repository.UpdateShipmentByTrader(shipmentID, status);
                if (check) {
                    Console.WriteLine("Updated!!!!!!");
                }
                else
                {
                    Console.WriteLine("Failed");
                }
            }
            catch(Exception e) 
            {
                Console.WriteLine("Error occured : "+e);
            }
        }
        public static void AddTraderPreference()
        {
            try
            {
                string traderID = "U123";
                string cropName = "Mustard";
                decimal minPrice = 20;
                decimal maxPrice = 70;
                decimal minQuantity = 200;
                decimal maxQuantity = 600;
                bool status = repository.AddTraderCropPreference(traderID, cropName, minPrice, maxPrice, minQuantity, maxQuantity);
                if (status) {
                    Console.WriteLine("Preference added for trader"+traderID); 
                }
                else
                {
                    Console.WriteLine("error");
                }
            }
            catch (Exception e) {
                Console.WriteLine(e);
            }
        }
        public static void getPreferedcrops()
        {
            try
            {
                var preferedCrops = repository.getPreferedCrops("U123");
                if (preferedCrops != null) {
                    Console.WriteLine("FarmerID, CropName, Quantity, Unit, PricePerUnit, Location, HarvestDate");
                    Console.WriteLine("-------------------------------------------------------------------------");
                    foreach (var item in preferedCrops)
                    {
                        Console.WriteLine("{0,-10} {1,-10} {2,-10} {3,-10} {4,-10} {5,-10} {6,-10}",
                            item.FarmerId, item.CropName, item.Quantity, item.Unit, item.PricePerUnit, item.Location, item.HarvestDate);
                    }
                }
                else
                {
                    Console.WriteLine("Emptyyy");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Some error occured");
            }
        }
        public static void test()
        {
            Console.WriteLine(repository.GetTransactionID("SH101"));
        }
        
    }
}
