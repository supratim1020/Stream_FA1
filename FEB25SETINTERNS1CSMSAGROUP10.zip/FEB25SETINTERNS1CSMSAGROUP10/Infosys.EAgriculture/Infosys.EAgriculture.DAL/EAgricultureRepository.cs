﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Infosys.EAgriculture.DAL.Models;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace Infosys.EAgriculture.DAL
{
    public class EAgricultureRepository
    {
        private EagriPortalDbContext context { get; set;}
        public EAgricultureRepository(EagriPortalDbContext context)
        {
            this.context = context;
        }

        public List<User> GetAllUsers()
        {
            List<User> usersList = new List<User>();
            try
            {
                usersList = context.Users.ToList();

            }
            catch (Exception) {
                usersList = null;
            }
            return usersList;
        }

        public User GetUserDetailsByID(string userId)
        {
            User user;
            try
            {
                user = (from u in context.Users where u.UserId.Equals(userId) select u).FirstOrDefault();
            }
            catch(Exception) {
                user=null;
            }
            return user;
        }

        //get CropDetails repoFunction
        public  List<CropAvailabilityDetail> getAllCropDetails()
        {
            List<CropAvailabilityDetail> productList = new List<CropAvailabilityDetail>();
            try
            {
                productList = context.CropAvailabilityDetails.ToList();
            }
            catch (Exception)
            {
                productList = null;
            }
            return productList;
        }

        // transaction history method
        public List<Transaction> getTransactionDetails()
        {
            List<Transaction> productList = new List<Transaction>();
            try
            {
                productList = context.Transactions.ToList();
            }
            catch (Exception)
            {
                productList = null;
            }
            return productList;
        }
        public List<ShipmentTrackingDetailOfTrader> GetShipmentTrackingDetailOfTraders(string traderID)
        {
            
            SqlParameter prmTraderID = new SqlParameter("@TraderID", traderID);
            List<ShipmentTrackingDetailOfTrader> res = new List<ShipmentTrackingDetailOfTrader>();
            try
            {
               
                res = context.ShipmentTrackingDetailOfTraders.FromSqlRaw("select * from ufn_GetShippmentTrackingDetails(@TraderID)", prmTraderID).ToList();
                
              
            }
            catch
            {
                res = null;
            }
        
            return res;
        }
        public string GetTransactionID(string shipmentID)
        {
            string transactionID = string.Empty;
            try
            {
                transactionID = (from s in context.Transactions 
                                 select EagriPortalDbContext.GetTransactionID(shipmentID)).FirstOrDefault();
            }
            catch(Exception)
            {
                transactionID = null;
            }
            return transactionID;
        }
        public string GetLastPreferenceID()
        {
            string lastPreferenceID = string.Empty;
            try
            {
                lastPreferenceID = (from s in context.TraderCropPreferences
                                    select EagriPortalDbContext.GetLastPreferenceID()).FirstOrDefault();

            }
            catch (Exception) { lastPreferenceID = null; }
            return lastPreferenceID;
        }
        public bool UpdateShipmentByTrader(string shipmentID,string status)
        { 
            bool res = false;
            ShipmentTracking shipment = context.ShipmentTrackings.Find(shipmentID);
            string transactionID = GetTransactionID(shipmentID);
            Transaction transaction = context.Transactions.Find(transactionID);
            try
            {
                shipment.Status = status;
                if(status== "Delivered")
                {
                    transaction.Status = "Completed";
       
                }
                if(status== "Cancelled")
                {
                    transaction.Status = status;
                }
                context.SaveChanges();
                res = true;
            }
            catch
            {
                res = false;
            }
            return res;
        }
        public bool AddTraderCropPreference(string traderID,string cropName,decimal minPrice,decimal maxPrice,decimal minQuantity,decimal maxQuantity)
        {
            bool res = false;
            try
            {
                if (minPrice < maxPrice && minQuantity < maxQuantity)
                {
                    string lastPreferenceID = GetLastPreferenceID();
                    string substring = lastPreferenceID.Substring(2);
                    int num = Convert.ToInt32(substring);
                    num++;
                    string newPreferenceID = "CP" + Convert.ToString(num);
                    TraderCropPreference traderCropPreference = new TraderCropPreference();
                    traderCropPreference.PreferenceId = newPreferenceID;
                    traderCropPreference.TraderId = traderID;
                    traderCropPreference.CropName = cropName;
                    traderCropPreference.MinPrice = minPrice;
                    traderCropPreference.MaxPrice = maxPrice;
                    traderCropPreference.MinQuantity = minQuantity;
                    traderCropPreference.MaxQuantity = maxQuantity;
                    context.TraderCropPreferences.Add(traderCropPreference);
                    context.SaveChanges();
                    res = true;
                }
                else
                {
                    res = false;
                }
            }
            catch
            {
                res = false;
            }
            return res;
        }
        public List<CropAvailabilityDetail> getPreferedCrops(string traderID)
        {
            List<CropAvailabilityDetail> res = new List<CropAvailabilityDetail>();
            try
            {
                List<TraderCropPreference> traderCropPreferences = context.TraderCropPreferences.Where(p => (p.TraderId == traderID)).ToList();
                List<CropAvailabilityDetail> allCrops = context.CropAvailabilityDetails.ToList();
                foreach(var prefer in traderCropPreferences)
                {
                    foreach (CropAvailabilityDetail crop in allCrops) {
                        if (prefer.CropName.ToLower().Equals(crop.CropName.ToLower())&&crop.Status=="Available")
                        {
                            if ((prefer.MinPrice <= crop.PricePerUnit && crop.PricePerUnit <= prefer.MaxPrice) || (prefer.MinQuantity <= crop.Quantity && crop.Quantity <= prefer.MaxQuantity))
                            {
                                
                                 res.Add(crop);
                            }
                            else
                            {
                                continue;
                            }
                        }
                        else
                        {
                            continue;
                        }
                    }
                }
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
                res = null;
            }
            return res;
        }
        public List<ShipmentTracking> data()
        {
            return context.ShipmentTrackings.ToList();
        }
    }
}
